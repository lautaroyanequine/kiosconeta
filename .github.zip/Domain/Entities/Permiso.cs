﻿namespace Domain.Entities
{
    public class Permiso
    {
        public int PermisoID { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public IList<EmpleadoPermiso> EmpleadoPermisos { get; set; }


    }
}
