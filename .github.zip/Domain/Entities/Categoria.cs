﻿namespace Domain.Entities
{
    public class Categoria
    {
        public int CategoriaID { get; set; }
        public string Nombre { get; set; }
    }
}
