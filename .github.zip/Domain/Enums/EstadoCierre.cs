﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Enums
{
    public enum EstadoCierre
    {
        Abierto = 1,
        Cerrado = 2,
        Ajustado = 3
    }
}
